import React, { useState } from 'react';
const UserForm = (props) => {


    const [form, setForm] = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        confirmPassword: "",
        hasBeenSubmitted: false
    })

    const [formErrors, setFormErrors] = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        confirmPassword: "",
        isValid: false
    })

    const createUser = (e) => {
        e.preventDefault();
        if (formErrors.isValid) {
            const newUser = { ...form };
            form.hasBeenSubmitted = true;
            console.log('Welcome', newUser);
        } else {
            console.log('Form was not valid');
        }
    };

    const onChangeHandler = (e) => {
        console.log(e.target.name)
        console.log(form)
        let lengthExpected = 0
        setForm({...form, [e.target.name]: e.target.value })
        if (e.target.name === "email") {
            lengthExpected = 5;
        } else {
            lengthExpected = 2
        }
        if (e.target.value.length < lengthExpected && e.target.value.length > 0) {
            setFormErrors({...formErrors,  [e.target.name]: `"${e.target.value}" is not long enough. Must be ${lengthExpected} or more characters`, isValid: false })

        } else {
            setFormErrors({...formErrors, [e.target.name]: "", isValid: true})

        }
    }

    const setPasswords = (e) => { 
        let confirmPw
        let pw
        if(e.target.name === "confirmPassword"){
            confirmPw = e.target.value
        } else {
            confirmPw = form.confirmPassword
        }
        if(e.target.name === "password"){
            pw = e.target.value
        } else {
            pw = form.password
        }
        setForm({...form, [e.target.name]: e.target.value  })
        console.log(`${e.target.name}: ${e.target.value}`)
        console.log(form)
        if (pw !== confirmPw) {
            console.log(`they dont match`)
            setFormErrors({...formErrors, ['password']: "Passwords Must Match", isValid: false })
        } else {
            console.log("Passwords MATCH")
            setFormErrors({...formErrors, ['password']: "", isValid: true})
        }
    }

    // const handleLastName = (e) => {
    //     setLastName(e.target.value)
    //     if (lastName.length < 2 && lastName.length > 0) {
    //         setLastNameError("Last Name is required and must be longer than 1 character")
    //         setIsValid(false)
    //     } else {
    //         setLastNameError("")
    //         setIsValid(true)

    //     }
    // }
    // const handlePassword = (e) => {
    //     setPassword(e.target.value)
    //     if (password !== confirmPassword && password.length > 0 && confirmPassword.length > 0) {
    //         setPasswordError("Passwords must match")
    //         setIsValid(false)
    //     } else {
    //         setPasswordError("")
    //         setIsValid(true)
    //     }
    // }

    // const handleConfirmPassword = (e) => {
    //     setConfirmPassword(e.target.value)
    //     // setConfirmPassword(confirmPassword)
    //     if (password !== confirmPassword && password.length > 0 && confirmPassword.length > 0) {
    //         setPasswordError("Passwords must match")
    //         setIsValid(false)
    //     } else {
    //         setPasswordError("")
    //         setIsValid(true)
    //     }
    // }

    // const handleEmail = (e) => {
    //     setEmail(e.target.value)
    //     if (email.length < 5 && email.length) {
    //         setEmailError("Email is required and must be longer than 5 character")
    //         setIsValid(false)
    //     } else {
    //         setEmailError("")
    //         setIsValid(true)
    //     }
    // }

    return (

        <form onSubmit={createUser}>
            {
                form.hasBeenSubmitted ?
                    <h3>Thank you for submitting the form!</h3> :
                    <h3>Welcome, please submit the form.</h3>
            }
            <div>
                <label>First Name: </label>
                <input type='text' onChange={onChangeHandler} name="firstName" />
                {
                    formErrors.firstName ?
                        <p style={{ color: 'red' }}>{formErrors.firstName}</p> :
                        ''
                }
            </div>
            <div>
                <label>Last Name: </label>
                <input type='text' onChange={onChangeHandler} name="lastName" />
                {
                    formErrors.lastName ?
                        <p style={{ color: 'red' }}>{formErrors.lastName}</p> :
                        ''
                }
            </div>
            <div>
                <label>Email: </label>
                <input type='text' onChange={onChangeHandler} name="email" />
                {
                    formErrors.email ?
                        <p style={{ color: 'red' }}>{formErrors.email}</p> :
                        ''
                }
            </div>
            <div>
                <label>Password: </label>
                <input type='text' onInput={setPasswords} name="password" />
                {
                    formErrors.password ?
                        <p style={{ color: 'red' }}>{formErrors.password}</p> :
                        ''
                }
            </div>
            <div>
                <label>Confirm Password: </label>
                <input type='text' onInput={setPasswords} name="confirmPassword" />
            </div>
            {/* <div>
                <label>Last Name: </label>
                <input type='text' onChange={handleLastName} value={lastName} />
                {
                    lastNameErorr ?
                        <p style={{ color: 'red' }}>{lastNameErorr}</p> :
                        ''
                }
            </div>
            <div>
                <label>Email Address: </label>
                <input type='text' onChange={handleEmail} value={email} />
                {
                    emailError ?
                        <p style={{ color: 'red' }}>{emailError}</p> :
                        ''
                }
            </div>
            <div>
                <label>Password: </label>
                <input type='text' onChange={handlePassword} value={password} />
                {
                    passwordErorr ?
                        <p style={{ color: 'red' }}>{passwordErorr}</p> :
                        ''
                }
            </div>
            <div>
                <label>Confirm Password: </label>
                <input type='text' onChange={handleConfirmPassword} value={confirmPassword} />
            </div>
            {isValid ?
                <input type='submit' value='Create User' /> :
                <p style={{ color: 'red' }}>Content is Not Valid</p>
            } */}
            <input type='submit' value='Create User' />
        </form>

    );
};
export default UserForm;